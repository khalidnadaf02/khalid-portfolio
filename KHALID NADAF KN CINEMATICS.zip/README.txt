Khalid Nadaf — Video Editor
--------------------------------
This is a simple single-page website for Khalid Nadaf, a professional video editor.

Files:
- index.html : Main website
- assets/ (empty) : Put images or videos here

How to publish:
1) GitHub Pages:
   - Create a new repository, upload these files, go to Settings → Pages → Select branch main and folder / (root).
   - Your site will be available at https://<username>.github.io/<repo-name> within a minute or two.

2) Netlify:
   - Drag & drop the zip or folder into Netlify Drop (app.netlify.com/drop) and your site will be live.

Contact:
khalidnadaf049@gmail.com
WhatsApp: +91 7248908638
YouTube: https://www.youtube.com/@3VIL_GAMING
Instagram: https://instagram.com/khxlid_nadaf
